"""
psycopg pool version file.
"""

# Copyright (C) 2021 The Psycopg Team

# Use a versioning scheme as defined in
# https://www.python.org/dev/peps/pep-0440/

# STOP AND READ! if you change:
__version__ = "3.1.10.dev1"
# also change:
# - `docs/news_pool.rst` to declare this version current or unreleased

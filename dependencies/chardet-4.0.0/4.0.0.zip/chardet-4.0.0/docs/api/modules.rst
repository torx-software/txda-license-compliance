chardet
=======

.. toctree::
   :maxdepth: 4

   chardet
